import discord

intents = discord.Intents.default()
intents.message_content = True

client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f'البوت اشتغل بنجاح: {client.user}')

@client.event
async def on_message(message):
    # حتى لا يرد البوت على نفسه
    if message.author == client.user:
        return

    # عندما يكتب أحدهم "السلام عليكم" أو "سلام عليكم"
    if message.content.startswith('السلام عليكم') or message.content.startswith('سلام عليكم'):
        await message.channel.send('وعليكم السلام ورحمة الله وبركاته 🌸')

# ضع توكن بوتك هنا بين علامتي التنصيص
client.run('MTUzNjExNjU5NDIzNTY3MDY1OA.GqvSwx.InjT1nJEblWcKZ_4n6OPfqDkkJO93KAak08ZtE')